function varargout = main(varargin)
% MAIN MATLAB code for main.fig
%      MAIN, by itself, creates a new MAIN or raises the existing
%      singleton*.
%
%      H = MAIN returns the handle to a new MAIN or the handle to
%      the existing singleton*.
%
%      MAIN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAIN.M with the given input arguments.
%
%      MAIN('Property','Value',...) creates a new MAIN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before main_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to main_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help main

% Last Modified by GUIDE v2.5 30-Apr-2022 13:03:44

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @main_OpeningFcn, ...
    'gui_OutputFcn',  @main_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before main is made visible.
function main_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to main (see VARARGIN)

% Choose default command line output for main
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes main wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = main_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in way.
function way_Callback(hObject, eventdata, handles)
% hObject    handle to way (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns way contents as cell array
%        contents{get(hObject,'Value')} returns selected item from way


% --- Executes during object creation, after setting all properties.
function way_CreateFcn(hObject, eventdata, handles)
% hObject    handle to way (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
[name,path]=uigetfile({'images/*.*'},'����ͼ��');
if isequal(name,0)|isequal(path,0)
    errordlg('û��ѡ���ļ���','����');
    return;
else
    Img1=imread([path,name]);  %��ȡλ��
    axes(handles.axes1);%axes��ʾ��ȡλ�ã�����ѡȡ��λ��Ϊaxes1��
    
    imshow(Img1); %��ʾͼ��
    title('ԭͼ', 'FontWeight', 'Bold');
    
    
    guidata(hObject,handles) %���½ṹ�壻
    save('Img1');  %�������
end
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
str1=sprintf('����˼·\n\n');
str2=sprintf(' �Ƚ���ȥ��������Ч��ͼ���ٶԱ����ۣ���Q�ң�115195686 \n');
string=[str1 str2];
msgbox(string,'��ܰ��ʾ','none');
return


Q = rgb2gray(Img1);
W = rgb2gray(Img2);
axes(handles.axes3); imhist(Q, 64); title('ԭ�Ҷ�ֱ��ͼ', 'FontWeight', 'Bold');
axes(handles.axes4); imhist(W, 64); title('������ĻҶ�ֱ��ͼ', 'FontWeight', 'Bold');
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
clc;
clear all;
close(gcf)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
str1=sprintf('����˼·\n\n');
str2=sprintf('    רעMATLAB��δ�����֣���Q�ң�115195686 \n');
string=[str1 str2];
msgbox(string,'��ܰ��ʾ','none');
return
load('Img1');
%handles.Img1=Img1;
pnum=get(handles.way,'value');
switch pnum
    case 1
        Img2 = quanju(Img1, 0);
        axes(handles.axes2); imshow(Img2, []);
        guidata(hObject, handles);
        set(handles.edit1, 'String', ...
            'ȫ��ֱ��ͼ���⻯ʵ��ͼ��ȥ���㷨��');
        
        imwrite(Img2,'ֱ��ͼȥ��Ч��ͼ.jpg');
    case 2
        I=Img1;
        %��Ӱȥ���㷨
        w0=0.65;   %0.65  �˻�������������һЩ����1ʱ��ȫȥ��
        t0=0.1;
        [h,w,s]=size(I);
        min_I=zeros(h,w);
        %����ȡ�ð�Ӱͨ��ͼ��
        for i=1:h
            for j=1:w
                dark_I(i,j)=min(I(i,j,:));
            end
        end
        %axes(handles.axes3)
        %imshow(dark_I);
        %title('dark channnel��ͼ��');
        Max_dark_channel=double(max(max(dark_I)))  %�������
        dark_channel=double(dark_I);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        I1=double(I);
        J(:,:,1) = uint8((I1(:,:,1) - (1-t)*Max_dark_channel)./t);
        J(:,:,2) = uint8((I1(:,:,2) - (1-t)*Max_dark_channel)./t);
        J(:,:,3) =uint8((I1(:,:,3) - (1-t)*Max_dark_channel)./t);
        axes(handles.axes2)
        imshow(J);
        title('ȥ�����ͼ��');
        Img2=J;
        set(handles.edit1, 'String', ...
            '���ڰ�ͨ��ȥ���㷨��');
        
        imwrite(Img2,'��ͨ��ȥ��Ч��ͼ.jpg');
        
    case 3
        Img2 = Retinex(Img1, 0);
        axes(handles.axes2); imshow(Img2, []);
        guidata(hObject, handles);
        set(handles.edit1, 'String', ...
            'RETINEX����ȥ���㷨��');
        
        imwrite(Img2,'Retinexȥ��Ч��ͼ.jpg');
    otherwise
end
save('Img2');
title('ȥ��Ч��ͼ', 'FontWeight', 'Bold');
%PSNR����
PSNR = PeakSignaltoNoiseRatio(Img1, Img2);
PSNR=num2str(PSNR)
set(handles.edit2,'string',PSNR);





% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)

% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
